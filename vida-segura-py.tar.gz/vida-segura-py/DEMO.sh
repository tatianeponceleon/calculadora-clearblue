#!/bin/bash

# Vida Segura - Demo Script
# Este script demonstra as funcionalidades do projeto

set -e

echo "╔════════════════════════════════════════════════════════════╗"
echo "║         Vida Segura - Calculadora Atuarial em Python      ║"
echo "║                    Script de Demonstração                 ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para imprimir seções
print_section() {
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
}

# Função para imprimir sucesso
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

# Função para imprimir aviso
print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

# Função para imprimir erro
print_error() {
    echo -e "${RED}✗ $1${NC}"
}

# Demo 1: Verificar estrutura do projeto
print_section "DEMO 1: Estrutura do Projeto"

echo "Arquivos principais:"
echo ""

if [ -f "src/calculadora.py" ]; then
    print_success "src/calculadora.py - Lógica atuarial"
    wc -l src/calculadora.py | awk '{print "  └─ " $1 " linhas"}'
else
    print_error "src/calculadora.py não encontrado"
fi

if [ -f "src/historico.py" ]; then
    print_success "src/historico.py - Gerenciador de histórico"
    wc -l src/historico.py | awk '{print "  └─ " $1 " linhas"}'
else
    print_error "src/historico.py não encontrado"
fi

if [ -f "web/app.py" ]; then
    print_success "web/app.py - API Flask"
    wc -l web/app.py | awk '{print "  └─ " $1 " linhas"}'
else
    print_error "web/app.py não encontrado"
fi

if [ -f "cli/main.py" ]; then
    print_success "cli/main.py - Interface CLI"
    wc -l cli/main.py | awk '{print "  └─ " $1 " linhas"}'
else
    print_error "cli/main.py não encontrado"
fi

# Demo 2: Rodar testes
print_section "DEMO 2: Executar Testes"

if command -v pytest &> /dev/null; then
    echo "Rodando pytest..."
    echo ""
    python -m pytest tests/ -v --tb=short 2>&1 | tail -20
    echo ""
    print_success "Testes executados com sucesso!"
else
    print_warning "pytest não está instalado. Execute: pip install -r requirements.txt"
fi

# Demo 3: Demonstrar cálculo via Python
print_section "DEMO 3: Cálculo Atuarial (Python API)"

echo "Importando módulos..."
python3 << 'EOF'
import sys
sys.path.insert(0, '.')

from src.calculadora import calcular_premio, formatar_brl, formatar_percentual

print("Calculando prêmio para:")
print("  • Idade: 35 anos")
print("  • Sexo: Masculino")
print("  • Capital: R$ 100.000")
print("  • Prazo: 10 anos")
print("")

result = calcular_premio(35, "M", 100000, "10")

print("Resultado:")
print(f"  • Prêmio Mensal: {formatar_brl(result['premio_mensal'])}")
print(f"  • Taxa de Risco: {formatar_percentual(result['taxa_risco'])}")
print(f"  • Cobertura até: {result['idade_final']} anos")
print("")

# Comparar com mulher
result_f = calcular_premio(35, "F", 100000, "10")
print("Comparação com mulher (mesmos parâmetros):")
print(f"  • Prêmio Feminino: {formatar_brl(result_f['premio_mensal'])}")
print(f"  • Diferença: {formatar_brl(result['premio_mensal'] - result_f['premio_mensal'])} ({formatar_percentual((1 - result_f['premio_mensal']/result['premio_mensal']) * 100)})")
EOF

# Demo 4: Demonstrar histórico
print_section "DEMO 4: Gerenciador de Histórico"

python3 << 'EOF'
import sys
import os
sys.path.insert(0, '.')

# Usar banco de dados temporário para demo
os.environ['DEMO'] = 'true'

from src.historico import HistoricoManager
import tempfile

# Criar banco temporário
fd, db_path = tempfile.mkstemp(suffix=".db")
os.close(fd)

try:
    manager = HistoricoManager(db_path)
    
    print("Adicionando simulações ao histórico...")
    print("")
    
    # Adicionar 3 simulações
    manager.add_simulation(35, "M", 100000, "10", 45.50, 0.546, 45)
    manager.add_simulation(40, "F", 150000, "15", 55.00, 0.350, 55)
    manager.add_simulation(50, "M", 200000, "20", 75.25, 0.890, 70)
    
    print("✓ 3 simulações adicionadas")
    print("")
    
    # Recuperar histórico
    history = manager.get_history()
    print(f"Histórico ({len(history)} itens):")
    print("")
    
    for i, item in enumerate(history, 1):
        print(f"{i}. {item.sex} {item.age}a • R$ {item.capital:,.0f} • {item.prazo}a")
        print(f"   └─ Prêmio: R$ {item.premio_mensal:.2f}/mês • Taxa: {item.taxa_risco:.4f}%")
    
    print("")
    
    # Estatísticas
    stats = manager.get_statistics()
    print("Estatísticas:")
    print(f"  • Total de simulações: {stats['total_simulations']}")
    print(f"  • Prêmio médio: R$ {stats['avg_monthly_premium']:.2f}")
    print(f"  • Capital total: R$ {stats['total_capital']:,.2f}")
    
finally:
    os.unlink(db_path)
EOF

# Demo 5: Informações sobre o projeto
print_section "DEMO 5: Informações do Projeto"

echo "Dependências instaladas:"
echo ""

python3 << 'EOF'
import sys
sys.path.insert(0, '.')

packages = [
    ('Flask', 'flask'),
    ('Supabase', 'supabase'),
    ('Pydantic', 'pydantic'),
    ('Click', 'click'),
    ('Pytest', 'pytest'),
]

for name, module in packages:
    try:
        mod = __import__(module)
        version = getattr(mod, '__version__', 'desconhecida')
        print(f"  ✓ {name:15} {version}")
    except ImportError:
        print(f"  ✗ {name:15} não instalado")
EOF

echo ""

# Demo 6: Próximos passos
print_section "DEMO 6: Próximos Passos"

echo "Para usar o Vida Segura:"
echo ""
echo "1. Interface Web:"
echo "   $ python web/app.py"
echo "   Acesse: http://localhost:5000"
echo ""
echo "2. Interface CLI:"
echo "   $ python cli/main.py calcular"
echo "   $ python cli/main.py historico"
echo "   $ python cli/main.py feedback"
echo ""
echo "3. Usar como biblioteca Python:"
echo "   from src.calculadora import calcular_premio"
echo "   result = calcular_premio(35, 'M', 100000, '10')"
echo ""
echo "4. Rodar testes:"
echo "   $ pytest tests/ -v"
echo ""

# Finalização
print_section "Demonstração Concluída!"

echo -e "${GREEN}Obrigado por usar o Vida Segura!${NC}"
echo ""
echo "Documentação:"
echo "  • README.md - Documentação completa"
echo "  • QUICKSTART.md - Guia de setup rápido"
echo "  • PRESENTATION.md - Script de apresentação"
echo ""
echo "Desenvolvido com ❤️ usando Python, Flask e Supabase"
echo ""
