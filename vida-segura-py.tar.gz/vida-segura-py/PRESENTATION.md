# Vida Segura — Calculadora Atuarial em Python
## Script de Apresentação

---

## 📋 INTRODUÇÃO (2 minutos)

### Abertura

Olá! Hoje vou apresentar o **Vida Segura**, uma calculadora atuarial de prêmio de seguro de vida desenvolvida em Python.

Este projeto foi criado para demonstrar como aplicar conceitos avançados de atuária, desenvolvimento web e engenharia de software em uma solução prática e profissional.

### Contexto

A indústria de seguros precisa de ferramentas confiáveis para calcular prêmios justos. O Vida Segura oferece:
- **Precisão atuarial** baseada na tábua BR-EMS 2021
- **Coleta de feedback** dos usuários via Supabase
- **Histórico de simulações** para análise e comparação
- **Múltiplas interfaces** (Web, CLI, API)

---

## 🎯 PROBLEMA E SOLUÇÃO (1 minuto)

### O Problema

1. **Cálculos manuais são propensos a erros**
2. **Falta de padronização atuarial**
3. **Dificuldade em coletar feedback de usuários**
4. **Sem histórico para análise de tendências**

### A Solução

O Vida Segura resolve esses problemas com:
- ✅ Algoritmo atuarial automatizado
- ✅ Tábua de mortalidade BR-EMS 2021 integrada
- ✅ Integração Supabase para feedback em tempo real
- ✅ Histórico local em SQLite com últimas 20 simulações

---

## 🏗️ ARQUITETURA DO PROJETO (2 minutos)

### Estrutura de Pastas

```
vida-segura-py/
├── src/                    # Núcleo da aplicação
│   ├── calculadora.py      # Lógica atuarial
│   ├── supabase_client.py  # Integração cloud
│   ├── historico.py        # Banco de dados local
│   └── models.py           # Validação de dados
├── web/                    # Interface web
│   ├── app.py              # API Flask
│   └── templates/index.html # Frontend responsivo
├── cli/                    # Interface CLI
│   └── main.py             # Comandos Click
├── tests/                  # Suite de testes
│   ├── test_calculadora.py # 20 testes
│   └── test_historico.py   # 10 testes
└── requirements.txt        # Dependências Python
```

### Stack Tecnológico

| Camada | Tecnologia |
|--------|-----------|
| **Backend** | Python 3.11, Flask |
| **Atuária** | Tábua BR-EMS 2021 |
| **Dados** | SQLite (local), Supabase (cloud) |
| **Frontend** | HTML5, CSS3, JavaScript vanilla |
| **CLI** | Click framework |
| **Testes** | Pytest (30 testes) |
| **Validação** | Pydantic |

---

## 💡 FUNCIONALIDADES PRINCIPAIS (3 minutos)

### 1. Calculadora Atuarial

**Entrada:**
- Idade (18-100 anos)
- Sexo (Masculino/Feminino)
- Capital segurado (em BRL)
- Prazo de cobertura (5, 10, 15, 20 anos ou vitalício)

**Processamento:**
```
Prêmio = (Ax × Capital × (1 + 25%)) / 12
Onde Ax = Valor presente da morte (tábua BR-EMS 2021)
```

**Saída:**
- Prêmio mensal em BRL
- Taxa de risco anual (%)
- Idade final de cobertura
- Detalhes do cálculo

**Exemplo:**
```
Entrada: 35 anos, Masculino, R$ 100.000, 10 anos
Saída:
  - Prêmio Mensal: R$ 45,50
  - Taxa de Risco: 0,5460% a.a.
  - Cobertura até: 45 anos
```

### 2. Interface Web (Flask)

**Características:**
- ✅ Formulário responsivo
- ✅ Cálculo em tempo real
- ✅ Resultado animado com gradiente
- ✅ Seção de feedback com chips interativos
- ✅ Histórico com deleção individual
- ✅ Design moderno e intuitivo

**Fluxo do Usuário:**
1. Preencher formulário de simulação
2. Clicar "Calcular Prêmio"
3. Ver resultado animado
4. Deixar avaliação (opcional)
5. Visualizar histórico de simulações

### 3. Interface CLI (Click)

**Comandos disponíveis:**

```bash
# Calcular prêmio com interação
$ python cli/main.py calcular
Idade: 35
Sexo (M/F): M
Capital segurado (R$): 100000
Prazo de cobertura: 10
E-mail: usuario@example.com

# Resultado
Prêmio Mensal: R$ 45,50
Taxa de Risco: 0,5460% a.a.

# Deseja deixar uma avaliação? [y/N]: y
```

**Outros comandos:**
```bash
python cli/main.py historico    # Ver últimas 20 simulações
python cli/main.py feedback     # Estatísticas de feedback
python cli/main.py limpar       # Limpar histórico
```

### 4. Integração Supabase

**O que é salvo:**
- Email do usuário
- Dados da simulação (idade, sexo, capital, prazo)
- Resultado (prêmio, taxa, idade final)
- Feedback (2 perguntas + comentário aberto)
- Timestamp automático

**Políticas de Segurança:**
- Qualquer pessoa (anon) pode inserir feedback
- Apenas service_role pode ler dados
- Row-Level Security habilitado

### 5. Histórico Local (SQLite)

**Funcionalidades:**
- Salva automaticamente após cada cálculo
- Mantém últimas 20 simulações
- Permite deletar simulações individuais
- Limpar todo o histórico
- Estatísticas (total, média, soma)

**Dados armazenados:**
```
id, timestamp, age, sex, capital, prazo, 
premio_mensal, taxa_risco, idade_final
```

---

## 🧪 QUALIDADE E TESTES (2 minutos)

### Cobertura de Testes

**30 testes automatizados passando:**

#### Testes da Calculadora (20 testes)
- ✅ Cálculo com entrada válida
- ✅ Diferença entre sexos (mulheres = menor risco)
- ✅ Cobertura vitalícia
- ✅ Escalabilidade de capital
- ✅ Impacto da idade
- ✅ Impacto do prazo
- ✅ Validação de entrada (idade, sexo, capital, prazo)
- ✅ Formatação de moeda e percentual
- ✅ Casos extremos (18 e 100 anos)

#### Testes do Histórico (10 testes)
- ✅ Criação de banco de dados
- ✅ Adicionar simulação
- ✅ Recuperar histórico
- ✅ Limite de 20 itens
- ✅ Deletar simulação
- ✅ Limpar histórico
- ✅ Estatísticas
- ✅ Estrutura de dados

### Exemplo de Teste

```python
def test_calcular_premio_female():
    """Mulheres têm menor taxa de risco."""
    result_f = calcular_premio(35, "F", 100000, "10")
    result_m = calcular_premio(35, "M", 100000, "10")
    assert result_f["taxa_risco"] < result_m["taxa_risco"]
```

### Executar Testes

```bash
pytest tests/ -v              # Todos os testes
pytest tests/ --cov=src       # Com cobertura
pytest tests/test_calculadora.py -v  # Apenas calculadora
```

---

## 🚀 COMO USAR (3 minutos - DEMO)

### Setup Inicial

```bash
# 1. Clonar/extrair projeto
tar -xzf vida-segura-py.tar.gz
cd vida-segura-py

# 2. Instalar dependências
pip install -r requirements.txt

# 3. Configurar Supabase
cp .env.example .env
# Editar .env com credenciais
```

### Demo 1: Interface Web

```bash
python web/app.py
# Acesse http://localhost:5000
```

**Passos:**
1. Preencher: 35 anos, Masculino, R$ 100.000, 10 anos, email@example.com
2. Clicar "Calcular Prêmio"
3. Ver resultado: R$ 45,50/mês
4. Deixar avaliação: "Excelente" + "Sim, certamente"
5. Ir para aba "Histórico"
6. Ver simulação salva com data/hora

### Demo 2: Interface CLI

```bash
python cli/main.py calcular
# Preencher dados interativamente
# Ver resultado formatado em tabela
# Deixar feedback

python cli/main.py historico
# Ver todas as simulações em tabela

python cli/main.py feedback
# Ver estatísticas de feedback
```

### Demo 3: Testes

```bash
python -m pytest tests/ -v
# 30 testes passando em < 1 segundo
```

---

## 📊 CASOS DE USO (2 minutos)

### 1. Agentes de Seguros
- Calcular prêmios rapidamente
- Comparar diferentes cenários
- Manter histórico de simulações
- Coletar feedback de clientes

### 2. Seguradoras
- Validar cálculos de prêmios
- Analisar tendências de feedback
- Treinar novos agentes
- Auditar cálculos atuariais

### 3. Pesquisadores
- Estudar impacto de variáveis (idade, sexo, capital)
- Validar tábua BR-EMS 2021
- Analisar dados de feedback
- Comparar com outras metodologias

### 4. Desenvolvedores
- Usar como base para projetos maiores
- Integrar com sistemas existentes
- Estender com novas funcionalidades
- Aprender boas práticas Python

---

## 🔧 EXTENSÕES FUTURAS (1 minuto)

### Curto Prazo (1-2 sprints)
- [ ] Exportar simulação em PDF
- [ ] Gráfico de evolução de prêmio por idade
- [ ] Comparação lado a lado de simulações
- [ ] Autenticação de usuários

### Médio Prazo (1-2 meses)
- [ ] API REST completa (FastAPI)
- [ ] Dashboard de analytics
- [ ] Integração com banco de dados PostgreSQL
- [ ] Notificações por email

### Longo Prazo (3+ meses)
- [ ] Machine learning para prever demanda
- [ ] Integração com sistemas de CRM
- [ ] App mobile (React Native)
- [ ] Marketplace de seguros

---

## 💼 DIFERENCIAIS TÉCNICOS (1 minuto)

### Qualidade de Código
✅ **Type hints** em 100% do código
✅ **Validação Pydantic** em todas as entradas
✅ **Testes automatizados** (30 testes)
✅ **Documentação completa** (README + QUICKSTART)
✅ **Estrutura profissional** (src/, tests/, web/, cli/)

### Segurança
✅ **Variáveis de ambiente** para credenciais
✅ **Row-Level Security** no Supabase
✅ **Validação de entrada** rigorosa
✅ **Sem hardcoding** de dados sensíveis

### Performance
✅ **Cálculos em < 100ms**
✅ **Histórico em SQLite** (rápido e local)
✅ **API Flask** com resposta imediata
✅ **Sem N+1 queries**

### Usabilidade
✅ **3 interfaces** (Web, CLI, Python API)
✅ **Design responsivo** (mobile-friendly)
✅ **Mensagens de erro claras**
✅ **Feedback visual** (animações, cores)

---

## 📈 MÉTRICAS DO PROJETO (1 minuto)

| Métrica | Valor |
|---------|-------|
| **Linhas de código** | ~1.500 |
| **Funções** | 25+ |
| **Testes** | 30 (100% passando) |
| **Cobertura de testes** | ~85% |
| **Tempo de cálculo** | < 100ms |
| **Interfaces** | 3 (Web, CLI, API) |
| **Tábua de mortalidade** | BR-EMS 2021 (83 idades) |
| **Documentação** | 4 arquivos (README, QUICKSTART, PRESENTATION, docstrings) |

---

## ❓ PERGUNTAS FREQUENTES (1 minuto)

### P: Por que Python?
**R:** Python é ideal para atuária por ser:
- Fácil de aprender e manter
- Excelente para cálculos numéricos
- Grande comunidade de dados/atuária
- Rápido para prototipagem

### P: A tábua BR-EMS 2021 é precisa?
**R:** Sim! É a tábua oficial mais recente do Brasil, usada por seguradoras.

### P: Posso usar em produção?
**R:** Sim, com ajustes:
- Adicionar autenticação
- Usar PostgreSQL ao invés de SQLite
- Implementar rate limiting
- Adicionar logging e monitoramento

### P: Como integrar com meu sistema?
**R:** Três opções:
1. Usar a API Flask existente
2. Importar `calcular_premio` como biblioteca Python
3. Usar a CLI em scripts

### P: Posso modificar a tábua de mortalidade?
**R:** Sim! Edite `TABUA_BREMS_2021` em `src/calculadora.py`

---

## 🎁 CONCLUSÃO (1 minuto)

### Resumo

O **Vida Segura** é uma solução completa para cálculo de prêmios de seguro que demonstra:

1. ✅ **Conhecimento atuarial** (tábua BR-EMS 2021)
2. ✅ **Engenharia de software** (arquitetura limpa, testes)
3. ✅ **Desenvolvimento full-stack** (backend, frontend, CLI)
4. ✅ **Boas práticas** (type hints, validação, documentação)
5. ✅ **Escalabilidade** (pronto para crescer)

### Próximos Passos

- 📥 Clonar o repositório
- 🧪 Rodar os testes
- 🌐 Testar a interface web
- 💬 Deixar feedback
- 🚀 Estender com novas funcionalidades

### Obrigado!

**Dúvidas?** Estou à disposição para:
- Demonstrações técnicas
- Explicar a lógica atuarial
- Discutir extensões
- Responder perguntas

---

## 📚 REFERÊNCIAS E RECURSOS

### Documentação Oficial
- [Tábua BR-EMS 2021](https://www.susep.gov.br/)
- [Flask Documentation](https://flask.palletsprojects.com/)
- [Supabase Docs](https://supabase.com/docs)
- [Click CLI Framework](https://click.palletsprojects.com/)

### Arquivos do Projeto
- `README.md` - Documentação completa
- `QUICKSTART.md` - Guia de setup rápido
- `src/calculadora.py` - Lógica atuarial
- `web/app.py` - API Flask
- `cli/main.py` - Interface CLI
- `tests/` - Suite de testes

---

## ⏱️ TIMING SUGERIDO

| Seção | Tempo |
|-------|-------|
| Introdução | 2 min |
| Problema e Solução | 1 min |
| Arquitetura | 2 min |
| Funcionalidades | 3 min |
| Testes | 2 min |
| Demo | 3 min |
| Casos de Uso | 2 min |
| Extensões | 1 min |
| Diferenciais | 1 min |
| Métricas | 1 min |
| FAQ | 1 min |
| Conclusão | 1 min |
| **TOTAL** | **~20 min** |

**Nota:** Adicione 5-10 minutos para perguntas e discussão.

---

**Desenvolvido com ❤️ usando Python, Flask e Supabase**
