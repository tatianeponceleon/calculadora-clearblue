"""Data models for Vida Segura calculator."""

from pydantic import BaseModel, EmailStr, Field
from typing import Optional, Literal
from datetime import datetime


class SimulacaoInput(BaseModel):
    """Input for a simulation calculation."""

    age: int = Field(..., ge=18, le=100, description="Age in years")
    sex: Literal["M", "F"] = Field(..., description="Biological sex")
    capital: float = Field(..., gt=0, description="Capital amount in BRL")
    prazo: Literal["5", "10", "15", "20", "vitalicio"] = Field(
        ..., description="Coverage period"
    )
    email: str = Field(..., description="Email for feedback")


class SimulacaoResult(BaseModel):
    """Result of a simulation calculation."""

    age: int
    sex: Literal["M", "F"]
    capital: float
    prazo: str
    premio_mensal: float
    taxa_risco: float
    idade_final: int
    timestamp: datetime = Field(default_factory=datetime.now)


class Feedback(BaseModel):
    """Feedback from a user."""

    email: Optional[str] = None
    age: Optional[int] = None
    sex: Optional[str] = None
    capital: Optional[float] = None
    prazo: Optional[str] = None
    premio_mensal: Optional[float] = None
    taxa_risco: Optional[float] = None
    q1_clareza: Optional[str] = Field(
        None, description="Clarity/usefulness rating"
    )
    q2_contratar: Optional[str] = Field(
        None, description="Intent to contract rating"
    )
    comentario: Optional[str] = Field(None, description="Open feedback text")


class HistoricoItem(BaseModel):
    """Item in simulation history."""

    id: str
    timestamp: datetime
    age: int
    sex: Literal["M", "F"]
    capital: float
    prazo: str
    premio_mensal: float
    taxa_risco: float
    idade_final: int
