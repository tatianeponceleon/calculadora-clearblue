"""Vida Segura - Insurance Premium Calculator."""

from .calculadora import calcular_premio, formatar_brl, formatar_percentual
from .models import SimulacaoInput, SimulacaoResult, Feedback, HistoricoItem
from .supabase_client import get_supabase_manager
from .historico import get_historico_manager

__all__ = [
    "calcular_premio",
    "formatar_brl",
    "formatar_percentual",
    "SimulacaoInput",
    "SimulacaoResult",
    "Feedback",
    "HistoricoItem",
    "get_supabase_manager",
    "get_historico_manager",
]
