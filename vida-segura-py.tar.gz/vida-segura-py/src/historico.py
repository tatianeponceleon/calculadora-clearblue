"""Local history management using SQLite."""

import sqlite3
import json
from datetime import datetime
from typing import List, Optional
from pathlib import Path
from .models import HistoricoItem


class HistoricoManager:
    """Manages local simulation history in SQLite."""

    def __init__(self, db_path: str = "vida_segura.db"):
        """Initialize history manager with SQLite database."""
        self.db_path = db_path
        self.max_items = 20
        self._init_db()

    def _init_db(self):
        """Initialize database schema."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS historico (
                id TEXT PRIMARY KEY,
                timestamp TEXT NOT NULL,
                age INTEGER NOT NULL,
                sex TEXT NOT NULL,
                capital REAL NOT NULL,
                prazo TEXT NOT NULL,
                premio_mensal REAL NOT NULL,
                taxa_risco REAL NOT NULL,
                idade_final INTEGER NOT NULL
            )
        """
        )

        conn.commit()
        conn.close()

    def add_simulation(
        self,
        age: int,
        sex: str,
        capital: float,
        prazo: str,
        premio_mensal: float,
        taxa_risco: float,
        idade_final: int,
    ) -> str:
        """
        Add a simulation to history.

        Args:
            age: Age at simulation
            sex: Biological sex
            capital: Capital amount
            prazo: Coverage period
            premio_mensal: Monthly premium
            taxa_risco: Risk rate
            idade_final: Final age

        Returns:
            ID of the inserted record
        """
        import time
        import random
        sim_id = f"sim_{int(datetime.now().timestamp() * 1000)}_{random.randint(1000, 9999)}"
        timestamp = datetime.now().isoformat()

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute(
            """
            INSERT INTO historico
            (id, timestamp, age, sex, capital, prazo, premio_mensal, taxa_risco, idade_final)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
            (
                sim_id,
                timestamp,
                age,
                sex,
                capital,
                prazo,
                premio_mensal,
                taxa_risco,
                idade_final,
            ),
        )

        # Keep only last max_items records
        cursor.execute(
            """
            DELETE FROM historico WHERE id NOT IN (
                SELECT id FROM historico ORDER BY timestamp DESC LIMIT ?
            )
        """,
            (self.max_items,),
        )

        conn.commit()
        conn.close()

        return sim_id

    def get_history(self, limit: Optional[int] = None) -> List[HistoricoItem]:
        """
        Get simulation history.

        Args:
            limit: Maximum number of records to return

        Returns:
            List of HistoricoItem objects
        """
        if limit is None:
            limit = self.max_items

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT id, timestamp, age, sex, capital, prazo, premio_mensal, taxa_risco, idade_final
            FROM historico
            ORDER BY timestamp DESC
            LIMIT ?
        """,
            (limit,),
        )

        rows = cursor.fetchall()
        conn.close()

        items = []
        for row in rows:
            items.append(
                HistoricoItem(
                    id=row[0],
                    timestamp=datetime.fromisoformat(row[1]),
                    age=row[2],
                    sex=row[3],
                    capital=row[4],
                    prazo=row[5],
                    premio_mensal=row[6],
                    taxa_risco=row[7],
                    idade_final=row[8],
                )
            )

        return items

    def delete_simulation(self, sim_id: str) -> bool:
        """
        Delete a simulation from history.

        Args:
            sim_id: ID of the simulation to delete

        Returns:
            True if successful, False otherwise
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("DELETE FROM historico WHERE id = ?", (sim_id,))

            conn.commit()
            conn.close()

            return True
        except Exception as e:
            print(f"Error deleting simulation: {e}")
            return False

    def clear_history(self) -> bool:
        """
        Clear all history.

        Returns:
            True if successful, False otherwise
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("DELETE FROM historico")

            conn.commit()
            conn.close()

            return True
        except Exception as e:
            print(f"Error clearing history: {e}")
            return False

    def get_statistics(self) -> dict:
        """
        Get history statistics.

        Returns:
            Dictionary with statistics
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("SELECT COUNT(*) FROM historico")
            total = cursor.fetchone()[0]

            cursor.execute("SELECT AVG(premio_mensal) FROM historico")
            avg_premio = cursor.fetchone()[0] or 0

            cursor.execute("SELECT SUM(capital) FROM historico")
            total_capital = cursor.fetchone()[0] or 0

            conn.close()

            return {
                "total_simulations": total,
                "avg_monthly_premium": round(avg_premio, 2),
                "total_capital": round(total_capital, 2),
            }
        except Exception as e:
            print(f"Error calculating statistics: {e}")
            return {}


# Singleton instance
_historico_manager: Optional[HistoricoManager] = None


def get_historico_manager() -> HistoricoManager:
    """Get or create history manager instance."""
    global _historico_manager
    if _historico_manager is None:
        _historico_manager = HistoricoManager()
    return _historico_manager
