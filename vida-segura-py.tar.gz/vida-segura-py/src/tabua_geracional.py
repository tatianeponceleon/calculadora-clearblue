"""
Tábua Geracional com Fatores de Improvement de Longevidade

Implementa uma tábua geracional que ajusta as taxas de mortalidade
ao longo do tempo usando fatores de improvement (melhoria de longevidade).

Baseado em:
- Lee-Carter Model (1992)
- Escalas SOA/IBA de improvement
- Tábua BR-EMS 2021 como base
"""

from typing import Dict, Tuple
import math


# Tábua BR-EMS 2021 simplificada (amostra de idades)
# Formato: {idade: taxa_mortalidade_bruta}
TABUA_BR_EMS_2021 = {
    18: 0.00095, 19: 0.00098, 20: 0.00101, 21: 0.00104, 22: 0.00107,
    23: 0.00110, 24: 0.00113, 25: 0.00116, 26: 0.00119, 27: 0.00122,
    28: 0.00125, 29: 0.00128, 30: 0.00131, 31: 0.00134, 32: 0.00137,
    33: 0.00140, 34: 0.00144, 35: 0.00148, 36: 0.00152, 37: 0.00156,
    38: 0.00160, 39: 0.00165, 40: 0.00170, 41: 0.00175, 42: 0.00181,
    43: 0.00187, 44: 0.00193, 45: 0.00200, 46: 0.00207, 47: 0.00215,
    48: 0.00223, 49: 0.00232, 50: 0.00241, 51: 0.00251, 52: 0.00262,
    53: 0.00274, 54: 0.00287, 55: 0.00301, 56: 0.00316, 57: 0.00332,
    58: 0.00349, 59: 0.00368, 60: 0.00388, 61: 0.00410, 62: 0.00434,
    63: 0.00460, 64: 0.00489, 65: 0.00520, 66: 0.00555, 67: 0.00593,
    68: 0.00636, 69: 0.00683, 70: 0.00736, 71: 0.00795, 72: 0.00860,
    73: 0.00933, 74: 0.01014, 75: 0.01104, 76: 0.01204, 77: 0.01315,
    78: 0.01438, 79: 0.01574, 80: 0.01724, 81: 0.01890, 82: 0.02073,
    83: 0.02276, 84: 0.02500, 85: 0.02747, 86: 0.03019, 87: 0.03319,
    88: 0.03650, 89: 0.04014, 90: 0.04415, 91: 0.04856, 92: 0.05341,
    93: 0.05874, 94: 0.06459, 95: 0.07101, 96: 0.07806, 97: 0.08579,
    98: 0.09427, 99: 0.10357, 100: 1.0  # Idade máxima
}


class TauaGeracional:
    """
    Tábua Geracional com fatores de improvement de longevidade.
    
    Ajusta as taxas de mortalidade da tábua base (BR-EMS 2021) usando
    fatores de improvement anuais, simulando a melhoria de longevidade.
    
    Parâmetros:
    -----------
    tabua_base : Dict[int, float]
        Tábua de mortalidade base (ex: BR-EMS 2021)
    improvement_rate : float
        Taxa anual de melhoria de longevidade (ex: 0.01 para 1% a.a.)
    ano_base : int
        Ano de referência da tábua base (ex: 2021)
    """
    
    def __init__(
        self,
        tabua_base: Dict[int, float] = None,
        improvement_rate: float = 0.01,
        ano_base: int = 2021
    ):
        """
        Inicializa a tábua geracional.
        
        Args:
            tabua_base: Dicionário {idade: taxa_mortalidade}. Se None, usa BR-EMS 2021.
            improvement_rate: Taxa anual de melhoria (0.01 = 1% a.a.)
            ano_base: Ano de referência da tábua base
        """
        self.tabua_base = tabua_base or TABUA_BR_EMS_2021
        self.improvement_rate = improvement_rate
        self.ano_base = ano_base
        self._cache: Dict[Tuple[int, int], float] = {}
    
    def get_taxa_mortalidade(
        self,
        idade: int,
        ano_analise: int
    ) -> float:
        """
        Obtém a taxa de mortalidade ajustada pela melhoria de longevidade.
        
        Fórmula: q_x(ano) = q_x(ano_base) × (1 - improvement_rate)^(ano - ano_base)
        
        Args:
            idade: Idade do segurado
            ano_analise: Ano para o qual calcular a taxa
        
        Returns:
            Taxa de mortalidade ajustada (entre 0 e 1)
        
        Raises:
            ValueError: Se idade fora do intervalo válido
        """
        if idade < 18 or idade > 100:
            raise ValueError(f"Idade {idade} fora do intervalo [18, 100]")
        
        # Verificar cache
        cache_key = (idade, ano_analise)
        if cache_key in self._cache:
            return self._cache[cache_key]
        
        # Obter taxa base
        if idade not in self.tabua_base:
            # Interpolação linear para idades não tabeladas
            taxa_base = self._interpolar_taxa(idade)
        else:
            taxa_base = self.tabua_base[idade]
        
        # Aplicar fator de improvement
        anos_decorridos = ano_analise - self.ano_base
        fator_improvement = (1 - self.improvement_rate) ** anos_decorridos
        taxa_ajustada = taxa_base * fator_improvement
        
        # Garantir que taxa não ultrapasse 1.0
        taxa_ajustada = min(taxa_ajustada, 1.0)
        
        # Cachear resultado
        self._cache[cache_key] = taxa_ajustada
        
        return taxa_ajustada
    
    def _interpolar_taxa(self, idade: int) -> float:
        """
        Interpola linearmente a taxa de mortalidade para idades não tabeladas.
        
        Args:
            idade: Idade para interpolar
        
        Returns:
            Taxa interpolada
        """
        # Encontrar idades vizinhas na tábua
        idades_tabeladas = sorted(self.tabua_base.keys())
        
        if idade <= idades_tabeladas[0]:
            return self.tabua_base[idades_tabeladas[0]]
        if idade >= idades_tabeladas[-1]:
            return self.tabua_base[idades_tabeladas[-1]]
        
        # Interpolação linear
        for i in range(len(idades_tabeladas) - 1):
            x1, x2 = idades_tabeladas[i], idades_tabeladas[i + 1]
            if x1 <= idade <= x2:
                y1, y2 = self.tabua_base[x1], self.tabua_base[x2]
                taxa = y1 + (y2 - y1) * (idade - x1) / (x2 - x1)
                return taxa
        
        return self.tabua_base[idades_tabeladas[-1]]
    
    def get_probabilidade_sobrevivencia(
        self,
        idade_inicial: int,
        anos: int,
        ano_analise: int
    ) -> float:
        """
        Calcula a probabilidade de sobreviver 'anos' anos a partir de idade_inicial.
        
        Fórmula: ₜp_x = ∏(1 - q_{x+k}) para k=0 até t-1
        
        Args:
            idade_inicial: Idade inicial
            anos: Número de anos para sobreviver
            ano_analise: Ano de análise
        
        Returns:
            Probabilidade de sobrevivência (entre 0 e 1)
        """
        prob_sobrevivencia = 1.0
        
        for k in range(anos):
            idade_atual = idade_inicial + k
            if idade_atual > 100:
                break
            
            taxa_morte = self.get_taxa_mortalidade(idade_atual, ano_analise + k)
            prob_sobrevivencia *= (1 - taxa_morte)
        
        return prob_sobrevivencia
    
    def get_probabilidade_morte_no_ano(
        self,
        idade: int,
        ano_analise: int
    ) -> float:
        """
        Obtém a probabilidade de morte durante um ano específico.
        
        Args:
            idade: Idade
            ano_analise: Ano de análise
        
        Returns:
            Probabilidade de morte (entre 0 e 1)
        """
        return self.get_taxa_mortalidade(idade, ano_analise)
    
    def comparar_com_tabua_periodo(
        self,
        idade_inicial: int,
        prazo: int,
        ano_analise: int
    ) -> Dict[str, float]:
        """
        Compara o prêmio puro com tábua geracional vs. tábua de período.
        
        Args:
            idade_inicial: Idade inicial
            prazo: Prazo em anos
            ano_analise: Ano de análise
        
        Returns:
            Dicionário com comparação de prêmios
        """
        taxa_desconto = 0.03  # 3% a.a.
        v = 1 / (1 + taxa_desconto)  # Fator de desconto
        
        # Prêmio com tábua geracional
        premio_geracional = 0.0
        for t in range(1, prazo + 1):
            idade_morte = idade_inicial + t - 1
            if idade_morte > 100:
                break
            
            prob_sobreviver = self.get_probabilidade_sobrevivencia(
                idade_inicial, t - 1, ano_analise
            )
            taxa_morte = self.get_taxa_mortalidade(idade_morte, ano_analise + t - 1)
            vp_beneficio = (v ** t) * prob_sobreviver * taxa_morte
            premio_geracional += vp_beneficio
        
        # Prêmio com tábua de período (sem improvement)
        tabua_periodo = TauaGeracional(
            tabua_base=self.tabua_base,
            improvement_rate=0.0,  # Sem improvement
            ano_base=self.ano_base
        )
        
        premio_periodo = 0.0
        for t in range(1, prazo + 1):
            idade_morte = idade_inicial + t - 1
            if idade_morte > 100:
                break
            
            prob_sobreviver = tabua_periodo.get_probabilidade_sobrevivencia(
                idade_inicial, t - 1, ano_analise
            )
            taxa_morte = tabua_periodo.get_taxa_mortalidade(idade_morte, ano_analise + t - 1)
            vp_beneficio = (v ** t) * prob_sobreviver * taxa_morte
            premio_periodo += vp_beneficio
        
        reducao_percentual = (
            (premio_periodo - premio_geracional) / premio_periodo * 100
            if premio_periodo > 0 else 0
        )
        
        return {
            "premio_periodo": premio_periodo,
            "premio_geracional": premio_geracional,
            "reducao_percentual": reducao_percentual,
            "idade_inicial": idade_inicial,
            "prazo": prazo,
            "ano_analise": ano_analise
        }
    
    def limpar_cache(self):
        """Limpa o cache de taxas calculadas."""
        self._cache.clear()


if __name__ == "__main__":
    # Exemplo de uso
    tabua = TauaGeracional(improvement_rate=0.01, ano_base=2021)
    
    # Comparar prêmios
    resultado = tabua.comparar_com_tabua_periodo(
        idade_inicial=35,
        prazo=30,
        ano_analise=2024
    )
    
    print("Comparação de Prêmios (idade 35, prazo 30 anos, ano 2024):")
    print(f"  Prêmio com tábua de período: {resultado['premio_periodo']:.6f}")
    print(f"  Prêmio com tábua geracional: {resultado['premio_geracional']:.6f}")
    print(f"  Redução: {resultado['reducao_percentual']:.2f}%")
