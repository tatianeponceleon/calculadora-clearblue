"""
Calculadora de Prêmio de Seguro de Vida com Tábua Geracional

Implementa a lógica atuarial para cálculo de prêmio de seguro de vida
temporário com base em tábua geracional com fatores de improvement
de longevidade (melhoria de mortalidade ao longo do tempo).

Baseado em:
- Tábua BR-EMS 2021 como base
- Fatores de improvement SOA/IBA (~1% a.a.)
- Fórmula: P_puro = Σ(v^t × ₜ₋₁pₓ × qₓ₊ₜ₋₁)
"""

from typing import Literal
import math
from src.tabua_geracional import TauaGeracional, TABUA_BR_EMS_2021


# Constants
CARREGAMENTO = 0.25  # 25% loading
TAXA_JUROS = 0.03  # 3% annual interest
PRAZO_VITALICIO_IDADE = 120  # Assume coverage until age 120
IMPROVEMENT_RATE = 0.01  # 1% annual improvement in longevity
ANO_BASE_TABUA = 2021  # BR-EMS 2021 base year


def calcular_premio(
    idade: int,
    sexo: Literal["M", "F"],
    capital: float,
    prazo: Literal["5", "10", "15", "20", "vitalicio"],
    usar_geracional: bool = True,
    ano_analise: int = 2024,
) -> dict:
    """
    Calculate insurance premium using generational mortality table.

    Args:
        idade: Age in years (18-100)
        sexo: Biological sex ("M" or "F")
        capital: Capital amount in BRL
        prazo: Coverage period ("5", "10", "15", "20", or "vitalicio")
        usar_geracional: Use generational table (True) or period table (False)
        ano_analise: Year of analysis for improvement factors

    Returns:
        Dictionary with calculation results:
        - premio_mensal: Monthly premium in BRL
        - taxa_risco: Annual risk rate (%)
        - idade_final: Final age at end of coverage
        - detalhes: Detailed calculation info
        - comparacao: Comparison with period table (if geracional=True)
    """

    # Validate inputs
    if not 18 <= idade <= 100:
        raise ValueError("Age must be between 18 and 100")
    if sexo not in ("M", "F"):
        raise ValueError("Sex must be 'M' or 'F'")
    if capital <= 0:
        raise ValueError("Capital must be positive")
    if prazo not in ("5", "10", "15", "20", "vitalicio"):
        raise ValueError("Prazo must be one of: 5, 10, 15, 20, vitalicio")

    # Calculate final age
    if prazo == "vitalicio":
        idade_final = PRAZO_VITALICIO_IDADE
        prazo_anos = PRAZO_VITALICIO_IDADE - idade
    else:
        prazo_anos = int(prazo)
        idade_final = min(idade + prazo_anos, PRAZO_VITALICIO_IDADE)

    # Initialize generational table
    tabua = TauaGeracional(
        tabua_base=TABUA_BR_EMS_2021,
        improvement_rate=IMPROVEMENT_RATE if usar_geracional else 0.0,
        ano_base=ANO_BASE_TABUA
    )

    # Calculate pure premium using generational formula
    # P_puro = Σ(v^t × ₜ₋₁pₓ × qₓ₊ₜ₋₁)
    ax = 0.0
    v_desconto = 1.0 / (1.0 + TAXA_JUROS)  # Discount factor
    prob_sobrevivencia_acumulada = 1.0

    for t in range(1, prazo_anos + 1):
        idade_morte = idade + t - 1

        if idade_morte > 100:
            break

        # Get mortality rate from generational table
        taxa_morte = tabua.get_taxa_mortalidade(idade_morte, ano_analise + t - 1)

        # Discount factor at time t
        desconto_t = v_desconto ** t

        # Accumulate present value of death benefit
        # VP = desconto × prob_sobreviver_até_t × taxa_morte_em_t
        ax += desconto_t * prob_sobrevivencia_acumulada * taxa_morte

        # Update survival probability for next year
        prob_sobrevivencia_acumulada *= (1.0 - taxa_morte)

        # Stop if probability becomes negligible
        if prob_sobrevivencia_acumulada < 1e-10:
            break

    # Pure premium (per BRL 1 of capital)
    premio_puro_anual = ax * capital

    # Apply loading (25%)
    premio_carregado_anual = premio_puro_anual * (1.0 + CARREGAMENTO)

    # Convert to monthly
    premio_mensal = premio_carregado_anual / 12.0

    # Calculate annual risk rate (%)
    taxa_risco = (ax * 100.0) if ax > 0 else 0.0

    # Build result dictionary
    resultado = {
        "premio_mensal": round(premio_mensal, 2),
        "taxa_risco": round(taxa_risco, 4),
        "idade_final": idade_final,
        "detalhes": {
            "idade_inicial": idade,
            "sexo": sexo,
            "capital": capital,
            "prazo": prazo,
            "prazo_anos": prazo_anos,
            "premio_puro_anual": round(premio_puro_anual, 2),
            "premio_carregado_anual": round(premio_carregado_anual, 2),
            "carregamento_percentual": CARREGAMENTO * 100,
            "taxa_juros": TAXA_JUROS * 100,
            "tipo_tabua": "geracional" if usar_geracional else "período",
            "improvement_rate": IMPROVEMENT_RATE * 100 if usar_geracional else 0,
            "ano_analise": ano_analise,
        },
    }

    # Add comparison with period table if using generational
    if usar_geracional:
        comparacao = tabua.comparar_com_tabua_periodo(
            idade_inicial=idade,
            prazo=prazo_anos,
            ano_analise=ano_analise
        )
        resultado["comparacao"] = {
            "premio_periodo_unitario": round(comparacao["premio_periodo"], 6),
            "premio_geracional_unitario": round(comparacao["premio_geracional"], 6),
            "reducao_percentual": round(comparacao["reducao_percentual"], 2),
        }

    return resultado


def formatar_brl(valor: float) -> str:
    """Format value as Brazilian Real currency."""
    return f"R$ {valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def formatar_percentual(valor: float, casas: int = 2) -> str:
    """Format value as percentage."""
    return f"{valor:.{casas}f}%"
