"""Supabase client for feedback and data storage."""

import os
from typing import Optional
from datetime import datetime
from supabase import create_client, Client
from .models import Feedback


class SupabaseManager:
    """Manages Supabase connections and operations."""

    def __init__(self):
        """Initialize Supabase client."""
        self.url = os.getenv("SUPABASE_URL", "")
        self.key = os.getenv("SUPABASE_ANON_KEY", "")

        if not self.url or not self.key:
            raise ValueError(
                "SUPABASE_URL and SUPABASE_ANON_KEY environment variables must be set"
            )

        self.client: Client = create_client(self.url, self.key)

    def check_connection(self) -> bool:
        """Check if Supabase connection is working."""
        try:
            # Try to query the feedbacks table
            response = self.client.table("feedbacks").select("id").limit(1).execute()
            return True
        except Exception as e:
            print(f"Supabase connection error: {e}")
            return False

    def submit_feedback(self, feedback: Feedback) -> bool:
        """
        Submit feedback to Supabase.

        Args:
            feedback: Feedback object with user ratings and comments

        Returns:
            True if successful, False otherwise
        """
        try:
            data = {
                "created_at": datetime.now().isoformat(),
                "email": feedback.email,
                "age": feedback.age,
                "sex": feedback.sex,
                "capital": feedback.capital,
                "prazo": feedback.prazo,
                "premio_mensal": feedback.premio_mensal,
                "taxa_risco": feedback.taxa_risco,
                "q1_clareza": feedback.q1_clareza,
                "q2_contratar": feedback.q2_contratar,
                "comentario": feedback.comentario,
            }

            response = self.client.table("feedbacks").insert(data).execute()
            return True
        except Exception as e:
            print(f"Error submitting feedback: {e}")
            return False

    def get_feedbacks(self, limit: int = 100) -> list:
        """
        Retrieve recent feedbacks from Supabase.

        Args:
            limit: Maximum number of feedbacks to retrieve

        Returns:
            List of feedback records
        """
        try:
            response = (
                self.client.table("feedbacks")
                .select("*")
                .order("created_at", desc=True)
                .limit(limit)
                .execute()
            )
            return response.data if response.data else []
        except Exception as e:
            print(f"Error retrieving feedbacks: {e}")
            return []

    def get_feedbacks_by_email(self, email: str) -> list:
        """
        Retrieve feedbacks for a specific email.

        Args:
            email: Email address to filter by

        Returns:
            List of feedback records for the email
        """
        try:
            response = (
                self.client.table("feedbacks")
                .select("*")
                .eq("email", email)
                .order("created_at", desc=True)
                .execute()
            )
            return response.data if response.data else []
        except Exception as e:
            print(f"Error retrieving feedbacks for {email}: {e}")
            return []

    def get_statistics(self) -> dict:
        """
        Get feedback statistics.

        Returns:
            Dictionary with feedback statistics
        """
        try:
            feedbacks = self.get_feedbacks(limit=1000)

            if not feedbacks:
                return {
                    "total": 0,
                    "avg_clarity": 0,
                    "avg_intent": 0,
                    "with_comments": 0,
                }

            total = len(feedbacks)
            clarity_ratings = [
                f.get("q1_clareza") for f in feedbacks if f.get("q1_clareza")
            ]
            intent_ratings = [
                f.get("q2_contratar") for f in feedbacks if f.get("q2_contratar")
            ]
            with_comments = sum(1 for f in feedbacks if f.get("comentario"))

            return {
                "total": total,
                "clarity_ratings": len(clarity_ratings),
                "intent_ratings": len(intent_ratings),
                "with_comments": with_comments,
            }
        except Exception as e:
            print(f"Error calculating statistics: {e}")
            return {}


# Singleton instance
_supabase_manager: Optional[SupabaseManager] = None


def get_supabase_manager() -> SupabaseManager:
    """Get or create Supabase manager instance."""
    global _supabase_manager
    if _supabase_manager is None:
        _supabase_manager = SupabaseManager()
    return _supabase_manager
