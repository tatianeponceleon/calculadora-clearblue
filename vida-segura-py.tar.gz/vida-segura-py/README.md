# Vida Segura — Calculadora Atuarial em Python

Calculadora de prêmio de seguro de vida baseada na tábua BR-EMS 2021, com coleta de feedback e histórico de simulações via Supabase.

## Características

- **Cálculo Atuarial**: Tábua BR-EMS 2021 com carregamento de 25% e juros de 3% a.a.
- **Feedback**: Coleta de avaliações dos usuários no Supabase
- **Histórico**: Salva as últimas 20 simulações em SQLite local
- **Interfaces**: CLI e Web (Flask)
- **Testes**: Suite completa com pytest

## Estrutura do Projeto

```
vida-segura-py/
├── src/
│   ├── calculadora.py          # Lógica atuarial
│   ├── supabase_client.py      # Integração Supabase
│   ├── historico.py            # Gerenciamento de histórico
│   └── models.py               # Modelos de dados
├── web/
│   ├── app.py                  # Aplicação Flask
│   └── templates/              # Templates HTML
├── cli/
│   └── main.py                 # Interface CLI
├── tests/
│   ├── test_calculadora.py
│   ├── test_supabase.py
│   └── test_historico.py
├── requirements.txt
├── .env.example
└── README.md
```

## Instalação

```bash
# Clone ou navegue até o diretório
cd vida-segura-py

# Crie um ambiente virtual
python3.11 -m venv venv
source venv/bin/activate

# Instale as dependências
pip install -r requirements.txt

# Configure as variáveis de ambiente
cp .env.example .env
# Edite .env com suas credenciais Supabase
```

## Uso

### Interface Web (Flask)

```bash
python web/app.py
# Acesse http://localhost:5000
```

### Interface CLI

```bash
python cli/main.py
```

## Variáveis de Ambiente

```env
SUPABASE_URL=https://seu-projeto.supabase.co
SUPABASE_ANON_KEY=sua-chave-anon
SUPABASE_SERVICE_ROLE_KEY=sua-chave-service-role
```

## Testes

```bash
pytest tests/ -v
```

## Licença

MIT
