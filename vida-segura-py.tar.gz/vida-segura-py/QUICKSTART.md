# Vida Segura Python — Quick Start Guide

## Setup Rápido

### 1. Instalar Dependências

```bash
pip install -r requirements.txt
```

### 2. Configurar Variáveis de Ambiente

```bash
cp .env.example .env
```

Edite `.env` com suas credenciais Supabase:

```env
SUPABASE_URL=https://seu-projeto.supabase.co
SUPABASE_ANON_KEY=sua-chave-anon
SUPABASE_SERVICE_ROLE_KEY=sua-chave-service-role
```

### 3. Criar Tabela no Supabase

Execute o seguinte SQL no **SQL Editor** do seu projeto Supabase:

```sql
CREATE TABLE IF NOT EXISTS public.feedbacks (
  id            BIGSERIAL PRIMARY KEY,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  email         TEXT,
  age           INTEGER,
  sex           TEXT,
  capital       NUMERIC,
  prazo         TEXT,
  premio_mensal NUMERIC,
  taxa_risco    NUMERIC,
  q1_clareza    TEXT,
  q2_contratar  TEXT,
  comentario    TEXT
);

ALTER TABLE public.feedbacks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow anon insert" ON public.feedbacks
  FOR INSERT TO anon WITH CHECK (true);

CREATE POLICY "Allow service read" ON public.feedbacks
  FOR SELECT TO service_role USING (true);
```

## Uso

### Interface Web (Flask)

```bash
python web/app.py
```

Acesse **http://localhost:5000** no navegador.

### Interface CLI

```bash
# Calcular prêmio
python cli/main.py calcular

# Ver histórico
python cli/main.py historico

# Ver estatísticas de feedback
python cli/main.py feedback

# Limpar histórico
python cli/main.py limpar
```

## Testes

```bash
# Rodar todos os testes
pytest tests/ -v

# Rodar com cobertura
pytest tests/ --cov=src --cov-report=html
```

## Estrutura de Arquivos

```
vida-segura-py/
├── src/
│   ├── calculadora.py          # Lógica atuarial (BR-EMS 2021)
│   ├── supabase_client.py      # Cliente Supabase
│   ├── historico.py            # Gerenciador de histórico (SQLite)
│   ├── models.py               # Modelos Pydantic
│   └── __init__.py
├── web/
│   ├── app.py                  # Aplicação Flask
│   └── templates/
│       └── index.html          # Interface Web
├── cli/
│   └── main.py                 # Interface CLI (Click)
├── tests/
│   ├── test_calculadora.py     # Testes da calculadora
│   ├── test_historico.py       # Testes do histórico
│   └── __init__.py
├── requirements.txt
├── .env.example
├── README.md
└── QUICKSTART.md
```

## Exemplos de Uso

### Python Script

```python
from src.calculadora import calcular_premio, formatar_brl
from src.historico import get_historico_manager

# Calcular prêmio
result = calcular_premio(35, "M", 100000, "10")
print(f"Prêmio mensal: {formatar_brl(result['premio_mensal'])}")
print(f"Taxa de risco: {result['taxa_risco']}%")

# Salvar no histórico
historico = get_historico_manager()
historico.add_simulation(
    age=35,
    sex="M",
    capital=100000,
    prazo="10",
    premio_mensal=result["premio_mensal"],
    taxa_risco=result["taxa_risco"],
    idade_final=result["idade_final"]
)

# Ver histórico
history = historico.get_history()
for item in history:
    print(f"{item.timestamp}: {item.sex} {item.age}a - R$ {item.premio_mensal}")
```

### CLI

```bash
# Calcular e deixar feedback
$ python cli/main.py calcular
Idade: 35
Sexo (M/F): M
Capital segurado (R$): 100000
Prazo de cobertura: 10
E-mail: usuario@example.com

# Resultado
Prêmio Mensal: R$ 45,50
Taxa de Risco: 0.5460%

# Deseja deixar uma avaliação? [y/N]: y
Como foi a clareza da calculadora?: Excelente
Você contrataria este seguro?: Sim, certamente
Comentário (opcional): Muito bom!
```

## Troubleshooting

### Erro: "SUPABASE_URL not set"

Certifique-se de que o arquivo `.env` está no diretório raiz e contém as credenciais corretas.

### Erro: "Table feedbacks does not exist"

Execute o SQL de criação da tabela no Supabase SQL Editor.

### Erro: "Permission denied" ao instalar pacotes

Use `sudo pip install -r requirements.txt` ou crie um virtual environment:

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Próximos Passos

- Adicionar autenticação de usuários
- Exportar simulações em PDF
- Integrar com banco de dados PostgreSQL
- Criar API REST completa com FastAPI
- Adicionar gráficos de evolução de prêmio
