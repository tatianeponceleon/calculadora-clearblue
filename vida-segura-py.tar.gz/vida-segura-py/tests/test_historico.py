"""Tests for history manager."""

import pytest
import os
import tempfile
from src.historico import HistoricoManager


@pytest.fixture
def temp_db():
    """Create temporary database for testing."""
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    yield path
    os.unlink(path)


class TestHistoricoManager:
    """History manager tests."""

    def test_init_creates_database(self, temp_db):
        """Test that initialization creates database."""
        manager = HistoricoManager(temp_db)
        assert os.path.exists(temp_db)

    def test_add_simulation(self, temp_db):
        """Test adding a simulation."""
        manager = HistoricoManager(temp_db)

        sim_id = manager.add_simulation(
            age=35,
            sex="M",
            capital=100000,
            prazo="10",
            premio_mensal=45.50,
            taxa_risco=0.546,
            idade_final=45,
        )

        assert sim_id.startswith("sim_")

    def test_get_history_empty(self, temp_db):
        """Test getting empty history."""
        manager = HistoricoManager(temp_db)
        history = manager.get_history()

        assert history == []

    def test_get_history_with_items(self, temp_db):
        """Test getting history with items."""
        manager = HistoricoManager(temp_db)

        manager.add_simulation(35, "M", 100000, "10", 45.50, 0.546, 45)
        manager.add_simulation(40, "F", 150000, "15", 55.00, 0.350, 55)

        history = manager.get_history()

        assert len(history) == 2
        assert history[0].age == 40  # Most recent first
        assert history[1].age == 35

    def test_get_history_limit(self, temp_db):
        """Test history limit."""
        manager = HistoricoManager(temp_db)

        for i in range(25):
            manager.add_simulation(35 + i, "M", 100000, "10", 45.50, 0.546, 45 + i)

        history = manager.get_history()

        # Should keep only last 20
        assert len(history) <= 20

    def test_delete_simulation(self, temp_db):
        """Test deleting a simulation."""
        manager = HistoricoManager(temp_db)

        sim_id = manager.add_simulation(35, "M", 100000, "10", 45.50, 0.546, 45)
        history_before = manager.get_history()

        assert len(history_before) == 1

        manager.delete_simulation(sim_id)
        history_after = manager.get_history()

        assert len(history_after) == 0

    def test_clear_history(self, temp_db):
        """Test clearing all history."""
        manager = HistoricoManager(temp_db)

        manager.add_simulation(35, "M", 100000, "10", 45.50, 0.546, 45)
        manager.add_simulation(40, "F", 150000, "15", 55.00, 0.350, 55)

        history_before = manager.get_history()
        assert len(history_before) == 2

        manager.clear_history()
        history_after = manager.get_history()

        assert len(history_after) == 0

    def test_get_statistics(self, temp_db):
        """Test statistics calculation."""
        manager = HistoricoManager(temp_db)

        manager.add_simulation(35, "M", 100000, "10", 45.50, 0.546, 45)
        manager.add_simulation(40, "F", 200000, "15", 55.00, 0.350, 55)

        stats = manager.get_statistics()

        assert stats["total_simulations"] == 2
        assert stats["avg_monthly_premium"] > 0
        assert stats["total_capital"] == 300000

    def test_statistics_empty(self, temp_db):
        """Test statistics with empty history."""
        manager = HistoricoManager(temp_db)

        stats = manager.get_statistics()

        assert stats["total_simulations"] == 0
        assert stats["avg_monthly_premium"] == 0
        assert stats["total_capital"] == 0

    def test_simulation_item_structure(self, temp_db):
        """Test that simulation items have correct structure."""
        manager = HistoricoManager(temp_db)

        manager.add_simulation(35, "M", 100000, "10", 45.50, 0.546, 45)
        history = manager.get_history()

        item = history[0]
        assert item.id.startswith("sim_")
        assert item.age == 35
        assert item.sex == "M"
        assert item.capital == 100000
        assert item.prazo == "10"
        assert item.premio_mensal == 45.50
        assert item.taxa_risco == 0.546
        assert item.idade_final == 45
        assert item.timestamp is not None
