"""Tests for Vida Segura."""
