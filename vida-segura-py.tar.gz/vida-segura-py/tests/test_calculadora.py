"""Tests for actuarial calculator."""

import pytest
from src.calculadora import calcular_premio, formatar_brl, formatar_percentual


class TestCalculadoraBasic:
    """Basic calculator tests."""

    def test_calcular_premio_valid_input(self):
        """Test calculation with valid input."""
        result = calcular_premio(35, "M", 100000, "10")

        assert result["premio_mensal"] > 0
        assert result["taxa_risco"] > 0
        assert result["idade_final"] == 45

    def test_calcular_premio_female(self):
        """Test calculation for female."""
        result_f = calcular_premio(35, "F", 100000, "10")
        result_m = calcular_premio(35, "M", 100000, "10")

        # Both should have valid risk rates
        assert result_f["taxa_risco"] > 0
        assert result_m["taxa_risco"] > 0

    def test_calcular_premio_vitalicio(self):
        """Test calculation with vitalicio coverage."""
        result = calcular_premio(35, "M", 100000, "vitalicio")

        assert result["idade_final"] == 120

    def test_calcular_premio_capital_scaling(self):
        """Test that premium scales with capital."""
        result_100k = calcular_premio(35, "M", 100000, "10")
        result_200k = calcular_premio(35, "M", 200000, "10")

        # Premium should roughly double
        ratio = result_200k["premio_mensal"] / result_100k["premio_mensal"]
        assert 1.9 < ratio < 2.1

    def test_calcular_premio_age_impact(self):
        """Test that older age increases premium."""
        result_35 = calcular_premio(35, "M", 100000, "10")
        result_50 = calcular_premio(50, "M", 100000, "10")

        assert result_50["premio_mensal"] > result_35["premio_mensal"]

    def test_calcular_premio_prazo_impact(self):
        """Test that longer coverage increases premium."""
        result_5 = calcular_premio(35, "M", 100000, "5")
        result_20 = calcular_premio(35, "M", 100000, "20")

        assert result_20["premio_mensal"] > result_5["premio_mensal"]


class TestCalculadoraValidation:
    """Input validation tests."""

    def test_invalid_age_too_young(self):
        """Test that age below 18 raises error."""
        with pytest.raises(ValueError):
            calcular_premio(17, "M", 100000, "10")

    def test_invalid_age_too_old(self):
        """Test that age above 100 raises error."""
        with pytest.raises(ValueError):
            calcular_premio(101, "M", 100000, "10")

    def test_invalid_sex(self):
        """Test that invalid sex raises error."""
        with pytest.raises(ValueError):
            calcular_premio(35, "X", 100000, "10")

    def test_invalid_capital_negative(self):
        """Test that negative capital raises error."""
        with pytest.raises(ValueError):
            calcular_premio(35, "M", -100000, "10")

    def test_invalid_capital_zero(self):
        """Test that zero capital raises error."""
        with pytest.raises(ValueError):
            calcular_premio(35, "M", 0, "10")

    def test_invalid_prazo(self):
        """Test that invalid prazo raises error."""
        with pytest.raises(ValueError):
            calcular_premio(35, "M", 100000, "30")


class TestFormatting:
    """Formatting function tests."""

    def test_formatar_brl(self):
        """Test BRL formatting."""
        assert formatar_brl(100.00) == "R$ 100,00"
        assert formatar_brl(1000.50) == "R$ 1.000,50"
        assert formatar_brl(1000000.00) == "R$ 1.000.000,00"

    def test_formatar_percentual(self):
        """Test percentage formatting."""
        assert formatar_percentual(5.0) == "5.00%"
        assert formatar_percentual(0.546) == "0.55%"
        assert formatar_percentual(100.0) == "100.00%"

    def test_formatar_percentual_casas(self):
        """Test percentage formatting with custom decimal places."""
        assert formatar_percentual(5.123, 1) == "5.1%"
        assert formatar_percentual(5.123, 3) == "5.123%"


class TestEdgeCases:
    """Edge case tests."""

    def test_minimum_age(self):
        """Test calculation at minimum age."""
        result = calcular_premio(18, "M", 100000, "5")
        assert result["premio_mensal"] > 0

    def test_maximum_age(self):
        """Test calculation at maximum age."""
        result = calcular_premio(100, "M", 100000, "5")
        # At age 100 with 5 year coverage, premium might be very high but should be positive
        assert result["premio_mensal"] >= 0

    def test_small_capital(self):
        """Test calculation with small capital."""
        result = calcular_premio(35, "M", 1000, "5")
        assert result["premio_mensal"] > 0

    def test_large_capital(self):
        """Test calculation with large capital."""
        result = calcular_premio(35, "M", 10000000, "5")
        assert result["premio_mensal"] > 0

    def test_detalhes_structure(self):
        """Test that detalhes has expected structure."""
        result = calcular_premio(35, "M", 100000, "10")

        detalhes = result["detalhes"]
        assert "idade_inicial" in detalhes
        assert "sexo" in detalhes
        assert "capital" in detalhes
        assert "prazo" in detalhes
        assert "premio_puro_anual" in detalhes
        assert "premio_carregado_anual" in detalhes


class TestGenerationalTable:
    """Tests for generational table features."""

    def test_calcular_premio_geracional_default(self):
        """Test that generational table is used by default."""
        result = calcular_premio(35, "M", 100000, "10")
        
        assert result["detalhes"]["tipo_tabua"] == "geracional"
        assert result["detalhes"]["improvement_rate"] > 0

    def test_calcular_premio_periodo(self):
        """Test calculation with period table (no improvement)."""
        result = calcular_premio(35, "M", 100000, "10", usar_geracional=False)
        
        assert result["detalhes"]["tipo_tabua"] == "período"
        assert result["detalhes"]["improvement_rate"] == 0

    def test_geracional_vs_periodo_comparison(self):
        """Test that generational premium is lower than period."""
        result_geracional = calcular_premio(35, "M", 100000, "20", usar_geracional=True)
        result_periodo = calcular_premio(35, "M", 100000, "20", usar_geracional=False)
        
        # Generational should have lower premium for long-term coverage
        assert result_geracional["premio_mensal"] < result_periodo["premio_mensal"]

    def test_comparacao_structure(self):
        """Test that comparacao field exists and has expected structure."""
        result = calcular_premio(35, "M", 100000, "20", usar_geracional=True)
        
        assert "comparacao" in result
        comparacao = result["comparacao"]
        assert "premio_periodo_unitario" in comparacao
        assert "premio_geracional_unitario" in comparacao
        assert "reducao_percentual" in comparacao
        assert comparacao["reducao_percentual"] > 0

    def test_geracional_reduction_increases_with_term(self):
        """Test that reduction increases with longer coverage."""
        result_5 = calcular_premio(35, "M", 100000, "5", usar_geracional=True)
        result_20 = calcular_premio(35, "M", 100000, "20", usar_geracional=True)
        
        reducao_5 = result_5["comparacao"]["reducao_percentual"]
        reducao_20 = result_20["comparacao"]["reducao_percentual"]
        
        # Longer term should have more reduction benefit
        assert reducao_20 > reducao_5

    def test_geracional_reduction_increases_with_young_age(self):
        """Test that reduction increases for younger ages with longer terms."""
        result_25 = calcular_premio(25, "M", 100000, "20", usar_geracional=True)
        result_65 = calcular_premio(65, "M", 100000, "20", usar_geracional=True)
        
        reducao_25 = result_25["comparacao"]["reducao_percentual"]
        reducao_65 = result_65["comparacao"]["reducao_percentual"]
        
        # Both should have positive reduction from improvement
        assert reducao_25 > 0
        assert reducao_65 > 0

    def test_ano_analise_parameter(self):
        """Test that ano_analise parameter affects calculation."""
        result_2024 = calcular_premio(35, "M", 100000, "10", ano_analise=2024)
        result_2034 = calcular_premio(35, "M", 100000, "10", ano_analise=2034)
        
        # Future year should have lower premium due to more improvement
        assert result_2034["premio_mensal"] < result_2024["premio_mensal"]
