"""Tests for generational mortality table."""

import pytest
from src.tabua_geracional import TauaGeracional, TABUA_BR_EMS_2021


class TestTauaGeracional:
    """Test suite for TauaGeracional class."""

    def setup_method(self):
        """Set up test fixtures."""
        self.tabua = TauaGeracional(
            tabua_base=TABUA_BR_EMS_2021,
            improvement_rate=0.01,
            ano_base=2021
        )

    def test_initialization(self):
        """Test initialization with default parameters."""
        assert self.tabua.improvement_rate == 0.01
        assert self.tabua.ano_base == 2021
        assert len(self.tabua.tabua_base) > 0

    def test_get_taxa_mortalidade_base_year(self):
        """Test mortality rate at base year (no improvement applied)."""
        taxa = self.tabua.get_taxa_mortalidade(idade=30, ano_analise=2021)
        # Should be close to base table value
        assert 0.0 < taxa < 1.0

    def test_get_taxa_mortalidade_future_year(self):
        """Test mortality rate decreases in future years (improvement applied)."""
        taxa_2021 = self.tabua.get_taxa_mortalidade(idade=30, ano_analise=2021)
        taxa_2031 = self.tabua.get_taxa_mortalidade(idade=30, ano_analise=2031)
        # Future rate should be lower due to improvement
        assert taxa_2031 < taxa_2021

    def test_get_taxa_mortalidade_improvement_factor(self):
        """Test improvement factor calculation."""
        taxa_2021 = self.tabua.get_taxa_mortalidade(idade=35, ano_analise=2021)
        taxa_2024 = self.tabua.get_taxa_mortalidade(idade=35, ano_analise=2024)
        
        # Expected improvement: (1 - 0.01)^3 = 0.970299
        expected_taxa_2024 = taxa_2021 * (0.99 ** 3)
        assert abs(taxa_2024 - expected_taxa_2024) < 1e-6

    def test_get_taxa_mortalidade_invalid_age(self):
        """Test that invalid ages raise ValueError."""
        with pytest.raises(ValueError):
            self.tabua.get_taxa_mortalidade(idade=17, ano_analise=2021)
        
        with pytest.raises(ValueError):
            self.tabua.get_taxa_mortalidade(idade=101, ano_analise=2021)

    def test_get_taxa_mortalidade_boundary_ages(self):
        """Test boundary ages (18 and 100)."""
        taxa_18 = self.tabua.get_taxa_mortalidade(idade=18, ano_analise=2021)
        taxa_100 = self.tabua.get_taxa_mortalidade(idade=100, ano_analise=2021)
        
        assert 0.0 < taxa_18 < 1.0
        assert taxa_100 == 1.0  # Age 100 should have rate 1.0

    def test_get_taxa_mortalidade_increases_with_age(self):
        """Test that mortality rate increases with age."""
        taxa_30 = self.tabua.get_taxa_mortalidade(idade=30, ano_analise=2021)
        taxa_50 = self.tabua.get_taxa_mortalidade(idade=50, ano_analise=2021)
        taxa_70 = self.tabua.get_taxa_mortalidade(idade=70, ano_analise=2021)
        
        assert taxa_30 < taxa_50 < taxa_70

    def test_interpolacao_taxa(self):
        """Test linear interpolation for non-tabulated ages."""
        # Age 25 should be in table, but test interpolation logic
        taxa = self.tabua.get_taxa_mortalidade(idade=25, ano_analise=2021)
        assert 0.0 < taxa < 1.0

    def test_get_probabilidade_sobrevivencia_one_year(self):
        """Test survival probability for one year."""
        prob = self.tabua.get_probabilidade_sobrevivencia(
            idade_inicial=30,
            anos=1,
            ano_analise=2021
        )
        
        taxa_morte = self.tabua.get_taxa_mortalidade(idade=30, ano_analise=2021)
        expected_prob = 1.0 - taxa_morte
        
        assert abs(prob - expected_prob) < 1e-6

    def test_get_probabilidade_sobrevivencia_multiple_years(self):
        """Test survival probability for multiple years."""
        prob_5_anos = self.tabua.get_probabilidade_sobrevivencia(
            idade_inicial=30,
            anos=5,
            ano_analise=2021
        )
        
        # Should be less than 1.0 but greater than 0
        assert 0.0 < prob_5_anos < 1.0

    def test_get_probabilidade_sobrevivencia_decreases(self):
        """Test that survival probability decreases with more years."""
        prob_1_ano = self.tabua.get_probabilidade_sobrevivencia(
            idade_inicial=30, anos=1, ano_analise=2021
        )
        prob_10_anos = self.tabua.get_probabilidade_sobrevivencia(
            idade_inicial=30, anos=10, ano_analise=2021
        )
        prob_30_anos = self.tabua.get_probabilidade_sobrevivencia(
            idade_inicial=30, anos=30, ano_analise=2021
        )
        
        assert prob_1_ano > prob_10_anos > prob_30_anos

    def test_get_probabilidade_morte_no_ano(self):
        """Test death probability in a year."""
        prob_morte = self.tabua.get_probabilidade_morte_no_ano(
            idade=40,
            ano_analise=2021
        )
        
        assert 0.0 < prob_morte < 1.0

    def test_comparar_com_tabua_periodo(self):
        """Test comparison between generational and period tables."""
        resultado = self.tabua.comparar_com_tabua_periodo(
            idade_inicial=35,
            prazo=30,
            ano_analise=2024
        )
        
        # Geracional should have lower premium
        assert resultado["premio_geracional"] < resultado["premio_periodo"]
        assert resultado["reducao_percentual"] > 0
        assert resultado["reducao_percentual"] < 50  # Reasonable reduction

    def test_comparar_com_tabua_periodo_short_term(self):
        """Test comparison for short-term coverage."""
        resultado = self.tabua.comparar_com_tabua_periodo(
            idade_inicial=50,
            prazo=5,
            ano_analise=2024
        )
        
        # Reduction should be smaller for short terms
        assert resultado["reducao_percentual"] < 10

    def test_comparar_com_tabua_periodo_young_age(self):
        """Test comparison for young age (more improvement benefit)."""
        resultado_jovem = self.tabua.comparar_com_tabua_periodo(
            idade_inicial=25,
            prazo=30,
            ano_analise=2024
        )
        
        resultado_idoso = self.tabua.comparar_com_tabua_periodo(
            idade_inicial=65,
            prazo=30,
            ano_analise=2024
        )
        
        # Younger age should have more reduction benefit
        assert resultado_jovem["reducao_percentual"] > resultado_idoso["reducao_percentual"]

    def test_cache_functionality(self):
        """Test that caching works correctly."""
        # First call
        taxa_1 = self.tabua.get_taxa_mortalidade(idade=40, ano_analise=2021)
        
        # Second call (should use cache)
        taxa_2 = self.tabua.get_taxa_mortalidade(idade=40, ano_analise=2021)
        
        assert taxa_1 == taxa_2
        assert len(self.tabua._cache) > 0

    def test_limpar_cache(self):
        """Test cache clearing."""
        # Populate cache
        self.tabua.get_taxa_mortalidade(idade=40, ano_analise=2021)
        assert len(self.tabua._cache) > 0
        
        # Clear cache
        self.tabua.limpar_cache()
        assert len(self.tabua._cache) == 0

    def test_sem_improvement(self):
        """Test table without improvement (period table)."""
        tabua_periodo = TauaGeracional(
            tabua_base=TABUA_BR_EMS_2021,
            improvement_rate=0.0,
            ano_base=2021
        )
        
        taxa_2021 = tabua_periodo.get_taxa_mortalidade(idade=30, ano_analise=2021)
        taxa_2031 = tabua_periodo.get_taxa_mortalidade(idade=30, ano_analise=2031)
        
        # Without improvement, rates should be identical
        assert taxa_2021 == taxa_2031

    def test_high_improvement_rate(self):
        """Test with higher improvement rate."""
        tabua_alta = TauaGeracional(
            tabua_base=TABUA_BR_EMS_2021,
            improvement_rate=0.02,  # 2% a.a.
            ano_base=2021
        )
        
        taxa_2021 = tabua_alta.get_taxa_mortalidade(idade=30, ano_analise=2021)
        taxa_2031 = tabua_alta.get_taxa_mortalidade(idade=30, ano_analise=2031)
        
        # Higher improvement should result in lower rates
        assert taxa_2031 < taxa_2021
        
        # Compare reduction with standard 1%
        reducao_padrao = self.tabua.get_taxa_mortalidade(
            idade=30, ano_analise=2031
        ) / self.tabua.get_taxa_mortalidade(idade=30, ano_analise=2021)
        
        reducao_alta = taxa_2031 / taxa_2021
        
        # Higher improvement should have more reduction
        assert reducao_alta < reducao_padrao


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
