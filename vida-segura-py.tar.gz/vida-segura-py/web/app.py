"""Flask web application for Vida Segura calculator."""

import os
import sys
from pathlib import Path
from datetime import datetime

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv

from src.calculadora import calcular_premio, formatar_brl, formatar_percentual
from src.models import Feedback
from src.supabase_client import get_supabase_manager
from src.historico import get_historico_manager

# Load environment variables
load_dotenv()

app = Flask(__name__, template_folder="templates")
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-secret-key")

# Initialize managers
try:
    supabase = get_supabase_manager()
    supabase_available = supabase.check_connection()
except Exception as e:
    print(f"Warning: Supabase not available: {e}")
    supabase_available = False

historico = get_historico_manager()


@app.route("/")
def index():
    """Home page."""
    return render_template("index.html")


@app.route("/api/calcular", methods=["POST"])
def api_calcular():
    """API endpoint to calculate premium."""
    try:
        data = request.json

        # Validate input
        age = int(data.get("age", 0))
        sex = data.get("sex", "").upper()
        capital = float(data.get("capital", 0))
        prazo = data.get("prazo", "")
        email = data.get("email", "")

        if not all([age, sex, capital, prazo, email]):
            return jsonify({"error": "Missing required fields"}), 400

        # Calculate
        result = calcular_premio(age, sex, capital, prazo)

        # Save to history
        sim_id = historico.add_simulation(
            age=age,
            sex=sex,
            capital=capital,
            prazo=prazo,
            premio_mensal=result["premio_mensal"],
            taxa_risco=result["taxa_risco"],
            idade_final=result["idade_final"],
        )

        return jsonify(
            {
                "success": True,
                "sim_id": sim_id,
                "premio_mensal": result["premio_mensal"],
                "taxa_risco": result["taxa_risco"],
                "idade_final": result["idade_final"],
                "premio_mensal_fmt": formatar_brl(result["premio_mensal"]),
                "taxa_risco_fmt": formatar_percentual(result["taxa_risco"]),
            }
        )

    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": "Internal server error"}), 500


@app.route("/api/feedback", methods=["POST"])
def api_feedback():
    """API endpoint to submit feedback."""
    try:
        if not supabase_available:
            return jsonify({"error": "Supabase not available"}), 503

        data = request.json

        feedback = Feedback(
            email=data.get("email"),
            age=data.get("age"),
            sex=data.get("sex"),
            capital=data.get("capital"),
            prazo=data.get("prazo"),
            premio_mensal=data.get("premio_mensal"),
            taxa_risco=data.get("taxa_risco"),
            q1_clareza=data.get("q1_clareza"),
            q2_contratar=data.get("q2_contratar"),
            comentario=data.get("comentario"),
        )

        if supabase.submit_feedback(feedback):
            return jsonify({"success": True})
        else:
            return jsonify({"error": "Failed to submit feedback"}), 500

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": "Internal server error"}), 500


@app.route("/api/historico")
def api_historico():
    """API endpoint to get simulation history."""
    try:
        history = historico.get_history()
        return jsonify(
            {
                "success": True,
                "items": [
                    {
                        "id": item.id,
                        "timestamp": item.timestamp.isoformat(),
                        "age": item.age,
                        "sex": item.sex,
                        "capital": item.capital,
                        "prazo": item.prazo,
                        "premio_mensal": item.premio_mensal,
                        "taxa_risco": item.taxa_risco,
                        "idade_final": item.idade_final,
                    }
                    for item in history
                ],
            }
        )
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": "Internal server error"}), 500


@app.route("/api/historico/<sim_id>", methods=["DELETE"])
def api_delete_historico(sim_id):
    """API endpoint to delete a simulation from history."""
    try:
        if historico.delete_simulation(sim_id):
            return jsonify({"success": True})
        else:
            return jsonify({"error": "Failed to delete simulation"}), 500
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": "Internal server error"}), 500


@app.route("/api/stats")
def api_stats():
    """API endpoint to get statistics."""
    try:
        hist_stats = historico.get_statistics()

        supabase_stats = {}
        if supabase_available:
            supabase_stats = supabase.get_statistics()

        return jsonify(
            {
                "success": True,
                "history": hist_stats,
                "feedback": supabase_stats,
                "supabase_available": supabase_available,
            }
        )
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": "Internal server error"}), 500


@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors."""
    return jsonify({"error": "Not found"}), 404


@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors."""
    return jsonify({"error": "Internal server error"}), 500


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
