"""Command-line interface for Vida Segura calculator."""

import os
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent))

import click
from tabulate import tabulate
from datetime import datetime
from dotenv import load_dotenv

from src.calculadora import calcular_premio, formatar_brl, formatar_percentual
from src.models import Feedback
from src.supabase_client import get_supabase_manager
from src.historico import get_historico_manager

# Load environment variables
load_dotenv()


@click.group()
def cli():
    """Vida Segura - Insurance Premium Calculator."""
    pass


@cli.command()
@click.option("--age", type=int, prompt="Idade", help="Age in years (18-100)")
@click.option(
    "--sex",
    type=click.Choice(["M", "F"]),
    prompt="Sexo (M/F)",
    help="Biological sex",
)
@click.option(
    "--capital",
    type=float,
    prompt="Capital segurado (R$)",
    help="Capital amount in BRL",
)
@click.option(
    "--prazo",
    type=click.Choice(["5", "10", "15", "20", "vitalicio"]),
    prompt="Prazo de cobertura",
    help="Coverage period",
)
@click.option("--email", type=str, prompt="E-mail", help="Email address")
def calcular(age: int, sex: str, capital: float, prazo: str, email: str):
    """Calculate insurance premium."""
    try:
        click.echo("\n📊 Calculando prêmio...\n")

        result = calcular_premio(age, sex, capital, prazo)

        # Display results
        click.echo("=" * 60)
        click.echo("RESULTADO DA SIMULAÇÃO".center(60))
        click.echo("=" * 60)

        table_data = [
            ["Idade", f"{age} anos"],
            ["Sexo", "Masculino" if sex == "M" else "Feminino"],
            ["Capital Segurado", formatar_brl(capital)],
            ["Prazo de Cobertura", prazo if prazo != "vitalicio" else "Vitalício"],
            ["Idade Final", f"{result['idade_final']} anos"],
            ["", ""],
            ["Prêmio Mensal", formatar_brl(result["premio_mensal"])],
            ["Taxa de Risco", formatar_percentual(result["taxa_risco"])],
        ]

        click.echo(tabulate(table_data, tablefmt="plain"))
        click.echo("=" * 60)

        # Save to history
        historico = get_historico_manager()
        sim_id = historico.add_simulation(
            age=age,
            sex=sex,
            capital=capital,
            prazo=prazo,
            premio_mensal=result["premio_mensal"],
            taxa_risco=result["taxa_risco"],
            idade_final=result["idade_final"],
        )
        click.echo(f"\n✓ Simulação salva no histórico (ID: {sim_id})\n")

        # Ask for feedback
        if click.confirm("Deseja deixar uma avaliação?"):
            clarity = click.prompt(
                "Como foi a clareza da calculadora?",
                type=click.Choice(["Excelente", "Bom", "Regular", "Ruim"]),
            )
            intent = click.prompt(
                "Você contrataria este seguro?",
                type=click.Choice(["Sim, certamente", "Talvez", "Não"]),
            )
            comment = click.prompt(
                "Comentário (opcional)",
                type=str,
                default="",
                show_default=False,
            )

            feedback = Feedback(
                email=email,
                age=age,
                sex=sex,
                capital=capital,
                prazo=prazo,
                premio_mensal=result["premio_mensal"],
                taxa_risco=result["taxa_risco"],
                q1_clareza=clarity,
                q2_contratar=intent,
                comentario=comment if comment else None,
            )

            supabase = get_supabase_manager()
            if supabase.submit_feedback(feedback):
                click.echo("✓ Avaliação enviada com sucesso!\n")
            else:
                click.echo("✗ Erro ao enviar avaliação\n")

    except ValueError as e:
        click.echo(f"❌ Erro: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Erro inesperado: {e}", err=True)
        sys.exit(1)


@cli.command()
def historico():
    """View simulation history."""
    historico_mgr = get_historico_manager()
    history = historico_mgr.get_history()

    if not history:
        click.echo("📋 Nenhuma simulação no histórico\n")
        return

    click.echo("\n" + "=" * 80)
    click.echo("HISTÓRICO DE SIMULAÇÕES".center(80))
    click.echo("=" * 80)

    table_data = []
    for item in history:
        table_data.append(
            [
                item.timestamp.strftime("%d/%m/%Y %H:%M"),
                f"{item.age}a, {item.sex}",
                formatar_brl(item.capital),
                f"{item.prazo}a" if item.prazo != "vitalicio" else "Vitalício",
                formatar_brl(item.premio_mensal),
                formatar_percentual(item.taxa_risco),
            ]
        )

    headers = ["Data/Hora", "Perfil", "Capital", "Prazo", "Prêmio Mensal", "Taxa"]
    click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))

    # Statistics
    stats = historico_mgr.get_statistics()
    click.echo(f"\n📊 Estatísticas:")
    click.echo(f"  • Total de simulações: {stats['total_simulations']}")
    click.echo(f"  • Prêmio médio: {formatar_brl(stats['avg_monthly_premium'])}")
    click.echo(f"  • Capital total: {formatar_brl(stats['total_capital'])}\n")


@cli.command()
def feedback():
    """View feedback statistics."""
    try:
        supabase = get_supabase_manager()

        if not supabase.check_connection():
            click.echo("❌ Erro ao conectar ao Supabase\n", err=True)
            return

        stats = supabase.get_statistics()

        click.echo("\n" + "=" * 60)
        click.echo("ESTATÍSTICAS DE FEEDBACK".center(60))
        click.echo("=" * 60)

        table_data = [
            ["Total de avaliações", stats.get("total", 0)],
            ["Com resposta de clareza", stats.get("clarity_ratings", 0)],
            ["Com resposta de intenção", stats.get("intent_ratings", 0)],
            ["Com comentários", stats.get("with_comments", 0)],
        ]

        click.echo(tabulate(table_data, tablefmt="plain"))
        click.echo("=" * 60 + "\n")

    except Exception as e:
        click.echo(f"❌ Erro: {e}", err=True)
        sys.exit(1)


@cli.command()
def limpar():
    """Clear simulation history."""
    if click.confirm("Tem certeza que deseja limpar todo o histórico?"):
        historico_mgr = get_historico_manager()
        if historico_mgr.clear_history():
            click.echo("✓ Histórico limpo com sucesso!\n")
        else:
            click.echo("❌ Erro ao limpar histórico\n", err=True)


if __name__ == "__main__":
    cli()
